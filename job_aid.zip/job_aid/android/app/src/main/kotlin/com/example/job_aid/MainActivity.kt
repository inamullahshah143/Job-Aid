package com.example.job_aid

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
