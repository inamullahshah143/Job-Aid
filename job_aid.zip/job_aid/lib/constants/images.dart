class Images {
  static String user1 = "assets/user/user1.jpg";
  static String user2 = "assets/user/user2.jpg";
  static String user3 = "assets/user/user3.jpg";
  static String user4 = "assets/user/user4.jpg";
  static String user5 = "assets/user/user5.jpg";
  static String user6 = "assets/user/user6.jpg";
  static String user7 = "assets/user/user7.jpg";

  static String google = "assets/logo/google_icon.png";
  static String dropbox = "assets/logo/dropbox.png";
  static String gitlab = "assets/logo/gitlab.png";
  static String slack = "assets/logo/slack.png";
  static String bitbucket = "assets/logo/bitbucket.png";

  static String doc = "assets/icon/document.png";
  static String map = "assets/icon/map.png";
  static String museum = "assets/icon/museum.png";
  static String clock = "assets/icon/wall-clock.png";
}
