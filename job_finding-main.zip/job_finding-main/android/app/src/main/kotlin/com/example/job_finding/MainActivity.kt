package com.example.job_finding

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
