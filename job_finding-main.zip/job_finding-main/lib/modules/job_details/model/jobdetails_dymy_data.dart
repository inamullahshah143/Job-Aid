const List<String> jobRequirementList = [
  "Exceptional communication skills and team working skill",
  "Creative with an eye for shape and colour",
  "Know the principal of animation and you can create high prtotypes",
  "Figma,Xd & Sketch must know about this apps",
  "3 years of relevant industry experience",
  "Excelent problem- solving skills and familiary with technical constrains and limitations",
];
