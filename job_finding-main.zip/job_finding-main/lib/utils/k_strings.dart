class Kstrings {
  static const String appName = "Job Finding";
}
